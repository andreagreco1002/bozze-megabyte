# Foto

Le foto del negozio sono nostre, scattate in Via Tripoli 17 (ottobre 2026).
Le altre vengono da Pexels, licenza gratuita anche per uso commerciale (pexels.com/license).

- `riparazione-pc-mac.jpg` - https://www.pexels.com/photo/34514242/ - Portatile aperto sul banco con i componenti a vista
- `riparazione-smartphone-tablet.jpg` - https://www.pexels.com/photo/6755075/ - Sostituzione di un componente interno di uno smartphone con il cacciavite
- `recupero-dati.jpg` - https://www.pexels.com/photo/6429162/ - Hard disk aperto con il disco e la testina in vista
- `virus-sicurezza.jpg` - https://www.pexels.com/photo/8720589/ - Tastiera e schermo con righe di codice durante un controllo di sicurezza
- `assistenza-aziende.jpg` - https://www.pexels.com/photo/6466143/ - Pannello di rete con cavi ethernet ordinati
- `assistenza-remota.jpg` - https://www.pexels.com/photo/16129688/ - Tecnico al computer con due monitor durante un collegamento da remoto
- `vendita.jpg` - https://www.pexels.com/photo/31145466/ - Computer portatili esposti su tavoli in un negozio di informatica
- `telefonia-internet.jpg` - https://www.pexels.com/photo/4218546/ - Router Wi-Fi con le antenne su sfondo colorato
- `siti-web.jpg` - https://www.pexels.com/photo/12902944/ - Scrivania con computer portatile e tavoletta grafica per il disegno di un sito
- `gestionali.jpg` - https://www.pexels.com/photo/10020092/ - Tablet che mostra un pannello con grafici e statistiche
- `app.jpg` - https://www.pexels.com/photo/887751/ - Mano che tiene uno smartphone davanti a un computer portatile
- `automazioni.jpg` - https://www.pexels.com/photo/1148820/ - Armadio di rete con luci accese
- `documenti-pdf.jpg` - https://www.pexels.com/photo/6207369/ - Modulo stampato con i riquadri da compilare, sulla scrivania accanto a una penna (ritagliata)
- `visibilita-google.jpg` - https://www.pexels.com/photo/4543006/ - Mano che tiene uno smartphone con una mappa aperta
- `banco.jpg` - nostra - L'interno del negozio: il banco, le vetrine e gli scaffali
- `negozio.jpg` - nostra - La vetrina da fuori, con l'insegna e i marchi trattati
- `negozio-fronte.jpg` - nostra - La vetrina ripresa di fronte (seconda inquadratura)
